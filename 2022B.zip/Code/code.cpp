#include<iostream>
#include<fstream>
#include<iomanip>
#include<cwchar>
#include<cmath>
#include<algorithm>
using namespace std;
double power_bao = 2998000 * 0.735 * 3600 * 5.5;
double power_mi = 950 * pow(10, 3) * 3600 * 5.5;
const double Min_pow = 2998000 * 0.735 * 3600 * 5.5 + 950 * pow(10, 3) * 3600 * 5.5;
const double to_mo = 1.5 * pow(10, 6) / 365;
const double g = 10;
double k, M, P;
const double min_l1 = 3132, l1_minpow = 3490;
const double min_l2 = 640, l2_minpow = 950;    
const double k1 = 0.6; const double k2 = 1;
double V_reg[6];double V_ind[6];double V_agr[6];//WY=1 CO=2 NM=3 AZ=4 CA=5
void read_V()
{
    ifstream in;
    in.open("data_v.txt");
    for (int i = 1; i <= 5; i++) {
        cin >> V_reg[i] >> V_ind[i] >> V_agr[i];
    }
    cin >> k >> M >> P;
    in.close();
}
int num_value_b, num_value_m;
double l[3][500];double V[3][500];
struct data {
    double level;
    double value;
};
int compare(void* a, void* b) {
    struct data* p = (struct data*)a;
    struct data* q = (struct data*)b;
    return (-q->level + p->level);
}
struct data _a[105];
struct data _b[105];
double get_V_bo(double li)
{
    for (int i = 1; i <= num_value_b; i++) {
        if (li <= _a[i + 1].level) {
            double k = (_a[i + 1].value - _a[i].value) / (_a[i + 1].level - _a[i].level);
            return (li - _a[i].level) * k + _a[i].value;
        }
    }
    double k = (_a[num_value_b].value - _a[num_value_b - 1].value) / (_a[num_value_b].level - _a[num_value_b - 1].level);
    return (li - _a[num_value_b].level) * k + _a[num_value_b].value;
}
double get_l_bo(double V)
{
    for (int i = 1; i <= num_value_b; i++) {
        if (V <= _a[i + 1].value) {
            double k = (_a[i + 1].level - _a[i].level) / (_a[i + 1].value - _a[i].value);
            return (V - _a[i].value) * k + _a[i].level;
        }
    }
    double k = (_a[num_value_b].level - _a[num_value_b - 1].level) / (_a[num_value_b].value - _a[num_value_b - 1].value);
    return (V - _a[num_value_b].value) * k + _a[num_value_b].level;
}
double get_V_mi(double li)
{
    for (int i = 1; i <= num_value_m; i++) {
        if (li <= _b[i + 1].level) {
            double k = (_b[i + 1].value - _b[i].value) / (_b[i + 1].level - _b[i].level);
            return (li - _b[i].level) * k + _b[i].value;
        }
    }
    double k = (_b[num_value_m].value - _b[num_value_m - 1].value) / (_b[num_value_m].level - _b[num_value_m - 1].level);
    return (li - _b[num_value_m].level) * k + _b[num_value_m].value;
}
double get_l_mi(double V)
{
    for (int i = 1; i <= num_value_m; i++) {
        if (V <= _b[i + 1].value) {
            double k = (_b[i + 1].level - _b[i].level) / (_b[i + 1].value - _b[i].value);
            return (V - _b[i].value) * k + _b[i].level;
        }
    }
    double k = (_b[num_value_m].level - _b[num_value_m - 1].level) / (_b[num_value_m].value - _b[num_value_m - 1].value);
    return (V - _b[num_value_m].value) * k + _b[num_value_m].level;
}
double get_power(double h, double v)
{
    return k1 * k2 * v * g * h * 0.3048 * 1234 ;
}
double get_v(double h, double power)
{
    return power / k1 / k2 / g / (h * 0.3048) / 1234;
}
void get_value()
{
    ifstream in;
    in.open("data.txt");
    double a, b;
    while (in >> a >> b) {
        _a[++num_value_b].level = a;
        _a[num_value_b].value = b;
    }
    in.close();
    _a[++num_value_b].level = min_l1; _a[num_value_b].value = 0;
    int(*fp)(void*, void*);
    fp = &compare;
    qsort(_a+1, num_value_b, sizeof(struct data), (_CoreCrtNonSecureSearchSortCompareFunction)fp);
    in.open("data1.txt");
    while (in >> a >> b) {
        _b[++num_value_m].level = a;
        _b[num_value_m].value = b;
    }
    in.close();
    _b[++num_value_m].level = min_l2; _b[num_value_m].value = 0;
    qsort(_b + 1, num_value_m, sizeof(struct data), (_CoreCrtNonSecureSearchSortCompareFunction)fp);
}
int main()
{
    get_value();
    read_V();
    for (int i = 1; i <= 5; i++) {
        V_ind[i] = V_ind[i] * 1.547 / 1000 * 101940.6477312 * 24 / 1234;
        V_reg[i] = V_reg[i] * 1.547 / 1000 * 101940.6477312 * 24 / 1234;
        V_reg[i] = V_agr[i] * 1.547 / 1000 * 101940.6477312 * 24 / 1234;
    }
    double v1 = 0, v2 = 0;
    int day = 1;
    l[1][1] = P; l[2][1] = M;
    V[1][1] = get_V_bo(P);V[2][1] = get_V_mi(M);
    double power1 = 0, power2 = 0;
    do{
        v1 = v2 = 0;
        power1 = power2 = 0;
        for (int i = 1; i <= 3; i++) {
            v1 -= V_ind[i];
            v1 -= V_reg[i];
            v1 -= V_agr[i];
        }
        v1 -= V_ind[4] + V_reg[4] + V_agr[4];
        v2 -= V_ind[5] + V_reg[5] + V_agr[5];
        V[1][day + 1] = V[1][day] + v1;
        V[2][day + 1] = V[2][day] + v2;
        power1 = get_power(l[1][day] - l1_minpow, V_ind[4] + V_reg[4] + V_agr[4]);//Dynamic
        power2 = get_power(l[2][day] - l2_minpow, V_ind[5] + V_reg[5] + V_agr[5] + to_mo);
        V[2][day + 1] -= to_mo;
        double v3 = 0;
        double temp_day = (V[1][day] - get_V_bo(l1_minpow)) / (-v1);
        double temp_x = V[2][day] + v2 * temp_day - get_V_mi(l2_minpow);
        double power_left = Min_pow - power1 - power2;
        if (power_left < 0) {
            power_left = 0;
        }
        if (temp_x > 0) {
            v3 = get_v(l[2][day] - l2_minpow, power_left);
            V[2][day + 1] -= v3;
        }
        else {
            temp_x = -temp_x;
            v3 = k * temp_x / temp_day;
            double temp_v3 = get_v(l[1][day] - l1_minpow, power_left);
            if (v3 < temp_v3) {
                v3 = temp_v3;
            }
            V[2][day + 1] += v3;
            V[1][day + 1] -= v3;
        }
        l[1][day + 1] = get_l_bo(V[1][day + 1]); l[2][day + 1] = get_l_mi(V[2][day + 1]);
        day++;
        cout << setprecision(10) << l[1][day] << endl;
    } while (l[1][day] >= l1_minpow && l[2][day] >= l2_minpow);
    cout << day << endl;
    if (l[1][day] < l1_minpow) {
        cout << 1 << endl;
    }
    if(l[2][day] < l2_minpow){
        cout << 2 << endl;
    }
    return 0;
}
